/*
  ESPArto.h - Library providing resilient MQTT control framework for ESP8266
  Created by Phil Bowles, Jul 14 2017.
  Released into the public domain.
*/
#ifndef ESPArto_H
#define ESPArto_H
//
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <ArduinoOTA.h>
#include <Ticker.h>
#include <map>
#include <vector>
#include <string>
#include <queue>
#include <algorithm>
#include "mutex.h"
#include "pins.h"
#include "task.h"
//
// helper macros
//
#define CSTR(x) x.c_str()
#define TOPIC(x) (std::string(device)+"/" + x).c_str()
#define TXTIP(x) CSTR(x.toString())

class smartTicker: public Ticker {
	public:
		~smartTicker(){
//			Serial.printf("Ticker %08x DTOR\n",this);
		}
};
typedef void (*ESPARTO_VOID_POINTER_VOID)();
typedef void (*ESPARTO_VOID_POINTER_ARG)(uint32_t);
typedef void (*ESPARTO_VOID_POINTER_BOOL)(bool);
typedef void (*ESPARTO_VOID_POINTER_STRING_STRING)(String,String);

typedef std::map<std::string,ESPARTO_VOID_POINTER_STRING_STRING>	vMap;
typedef std::unique_ptr<task> 										pTask_t;
typedef std::deque<task*> 											taskQueue;
typedef std::unique_ptr<smartTicker> 								pTicker_t;
typedef std::pair<pTicker_t,pTask_t> 								tickerPair;
typedef std::vector<tickerPair> 									tickerList;

class ESPArto {
	friend class pubTask;
	friend class subTask;
	
	friend class hwPin;
	friend class encoderPinPair;
	
	public:
		ESPArto(const char* _SSID,const char* _pwd, const char* _device, const char * _mqttIP,int _mqttPort,bool _debug=true);
		~ESPArto(){};
		void debugMode(bool torf){debug=torf;};
		void every(int msec,ESPARTO_VOID_POINTER_VOID fn);
		void every(int msec,ESPARTO_VOID_POINTER_ARG fn,uint32_t arg);
		void loop();
		void never(ESPARTO_VOID_POINTER_VOID fn);
		void never(ESPARTO_VOID_POINTER_ARG fn);
		void once(int msec,ESPARTO_VOID_POINTER_VOID fn);
		void once(int msec,ESPARTO_VOID_POINTER_ARG fn,uint32_t arg);
		void pinDefDebounce(uint8_t pin,uint8_t mode,ESPARTO_VOID_POINTER_BOOL, unsigned int ms);
		void pinDefEncoder(uint8_t pinA,uint8_t pinB,uint8_t mode,ESPARTO_VOID_POINTER_BOOL fn);
		void pinDefLatch(uint8_t pin,uint8_t mode,ESPARTO_VOID_POINTER_BOOL, unsigned int ms);
		void pinDefRetrigger(uint8_t pin,uint8_t mode,ESPARTO_VOID_POINTER_BOOL,unsigned int ms);
		void pinDefRaw(uint8_t pin,uint8_t mode,ESPARTO_VOID_POINTER_BOOL);
		bool pinIsLatched(uint8_t pin);
		void publish(String topic,String payload);
		void publish(const char* topic,const char* payload);
		void pulsePin(uint8_t pin,unsigned int ms,bool active=HIGH);
		void subscribe(const char * topic,ESPARTO_VOID_POINTER_STRING_STRING fn);
		
		static int	frigdelay; // ****************************

	private:
		static	volatile	int					avgQLength;
		static  volatile	int 				avgQSigma;
		static	volatile	int 				avgQCount;
		static				Ticker				avgQLengthTicker;		
		static volatile 	uint8_t 			Layer;
		
		static 				vMap 				topicFn;
		static volatile 	bool				linked;

		static 				std::string			device;
		static 				taskQueue	 		taskQ;
		static 				mutex_t				tqMutex;
		static 				bool				debug;
//
		static 				tickerList			tickers;
		static 				pinList				hwPins;
//
							WiFiClient     		wifiClient;
							WiFiEventHandler    _gotIpEventHandler,_disconnectedEventHandler;
		static 				PubSubClient*		mqttClient;
//
							const char *		SSID;
							const char *		pwd;
//
				void 		_L0SynchHandler();
				void 		_L1Elevate();
				void 		_L1SetupSTA();
				void 		_L1SynchHandler();
		static 	void 		_L2Setup();
				void 		_L2SynchHandler();
				
				void runTasks();
				void _asynchPublish(const char* topic,const char* payload);
		static 	void waitMutex();
				void __timerCore(int msec,ESPARTO_VOID_POINTER_ARG fn,bool once,uint32_t arg=0);
				void _cleanTask(task* tsk,bool clrQ=false);
		static 	void queueTask(task* t);
		static 	void queueFunction(ESPARTO_VOID_POINTER_VOID fn);
		static  void queueFunction(ESPARTO_VOID_POINTER_ARG fn,uint32_t arg);
		static 	void mqttCallback(char* topic, byte* payload, unsigned int length);
		static 	void _wifiGotIPHandler(const WiFiEventStationModeGotIP& event);
		static 	void _wifiDisconnectHandler(const WiFiEventStationModeDisconnected& event);

		static 	void _wifiEvent(WiFiEvent_t);
		static 	void say(const char *fmt, ... );
		static	void split(const std::string& s, char delim,std::vector<std::string>& v);

	};
extern ESPArto Esparto;
//
//  Caller MUST provide:
//
extern	void setupHardware();
extern	void checkHardware();
extern 	void onMqttConnect();

#endif // ESPArto_H