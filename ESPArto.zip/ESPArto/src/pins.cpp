#include <ESPArto.h>
#include "pins.h"

void hwPin::__signal(uint8_t x){
	ESPArto::queueFunction(fn,x);
}
void hwPin::_signal(){
	__signal(state);
}

void debouncePin::_pinChange(){
	if(us - lastChange > debounce) _signal();
	lastChange=us;
}

void latchPin::_signal(){
	latchCount++;
	if(latchCount>1){
		latched=!latched;
		hwPin::_signal();
		latchCount=0;
	}
}

void retriggerPin::_pinChange(){
	if(!lastChange) _signal();
	lastChange=us;
}

void retriggerPin::run(){
	hwPin::run();
	if(lastChange && (micros() - lastChange > holdoff)){
		_signal();
		lastChange=0;	
	}
}

void encoderPinPair::run(){
	hwPin::run();
	uint8_t instant=digitalRead(pinB);
	if(bState!=instant){
		bState=instant;
		_pinChange();
	}
}

void encoderPinPair::_pinChange(){
	static const 	int8_t rot_states[] =   {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};
	static 			uint8_t AB = 0x03;
	uint8_t 		pins;
	static 			int8_t val=0;
	
	pins=(state<<1) | bState;
	AB <<= 2;                  // save previous state
	AB |= (pins & 0x03);     // add current state
	val+=rot_states[AB & 0x0f];
	if(val==4 || val==-4){
		ESPArto::queueFunction(fn,(uint32_t) (val < 0 ? 0:1));
		val=0;
	}
}